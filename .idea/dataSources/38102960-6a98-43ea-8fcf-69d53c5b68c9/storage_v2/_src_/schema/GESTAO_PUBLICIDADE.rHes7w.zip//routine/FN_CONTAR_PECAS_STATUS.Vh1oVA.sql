create FUNCTION FN_CONTAR_PECAS_STATUS(
    p_status IN VARCHAR2
) RETURN NUMBER AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_count
    FROM Pecas_Criativas
    WHERE UPPER(Status_aprov) = UPPER(p_status);

    RETURN NVL(v_count, 0);
EXCEPTION
    WHEN OTHERS THEN
        RETURN 0;
END;
/

