create PROCEDURE SP_PESQUISA_ESPACOS(
    p_termo IN VARCHAR2,
    p_campo IN VARCHAR2 DEFAULT 'TODOS',
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    CASE p_campo
        WHEN 'LOCAL' THEN
            OPEN p_cursor FOR
                SELECT * FROM Espaco_Dados
                WHERE UPPER(Local_fis_dig) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Local_fis_dig;

        WHEN 'TIPO' THEN
            OPEN p_cursor FOR
                SELECT * FROM Espaco_Dados
                WHERE UPPER(Tipo) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Tipo;

        WHEN 'DISPONIBILIDADE' THEN
            OPEN p_cursor FOR
                SELECT * FROM Espaco_Dados
                WHERE UPPER(Disponibilidade) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Disponibilidade;

        WHEN 'PROPRIETARIO' THEN
            OPEN p_cursor FOR
                SELECT * FROM Espaco_Dados
                WHERE UPPER(Proprietario) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Proprietario;

        ELSE -- TODOS
            OPEN p_cursor FOR
                SELECT * FROM Espaco_Dados
                WHERE UPPER(NVL(Local_fis_dig, '') || ' ' || NVL(Tipo, '') || ' ' ||
                           NVL(Visibilidade, '') || ' ' || NVL(Proprietario, ''))
                      LIKE UPPER('%' || p_termo || '%')
                ORDER BY Local_fis_dig;
    END CASE;
END;
/

