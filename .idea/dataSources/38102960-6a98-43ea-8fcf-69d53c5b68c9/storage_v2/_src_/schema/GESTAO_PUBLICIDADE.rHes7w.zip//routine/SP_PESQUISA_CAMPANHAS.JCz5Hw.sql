create PROCEDURE SP_PESQUISA_CAMPANHAS(
    p_termo IN VARCHAR2,
    p_campo IN VARCHAR2 DEFAULT 'TODOS',
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    CASE p_campo
        WHEN 'TITULO' THEN
            OPEN p_cursor FOR
                SELECT * FROM Campanha_Dados
                WHERE UPPER(Titulo) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Data_inicio DESC;

        WHEN 'CODIGO' THEN
            OPEN p_cursor FOR
                SELECT * FROM Campanha_Dados
                WHERE TO_CHAR(Cod_camp) LIKE '%' || p_termo || '%'
                ORDER BY Cod_camp DESC;

        WHEN 'PUBLICO' THEN
            OPEN p_cursor FOR
                SELECT * FROM Campanha_Dados
                WHERE UPPER(Pub_alvo) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Data_inicio DESC;

        WHEN 'ORCAMENTO' THEN
            OPEN p_cursor FOR
                SELECT * FROM Campanha_Dados
                WHERE TO_CHAR(Orc_alocado) LIKE '%' || p_termo || '%'
                ORDER BY Orc_alocado DESC;

        ELSE -- TODOS
            OPEN p_cursor FOR
                SELECT * FROM Campanha_Dados
                WHERE UPPER(NVL(Titulo, '') || ' ' || NVL(Pub_alvo, '')) LIKE UPPER('%' || p_termo || '%')
                   OR TO_CHAR(Cod_camp) LIKE '%' || p_termo || '%'
                   OR TO_CHAR(Orc_alocado) LIKE '%' || p_termo || '%'
                ORDER BY Data_inicio DESC;
    END CASE;
END;
/

