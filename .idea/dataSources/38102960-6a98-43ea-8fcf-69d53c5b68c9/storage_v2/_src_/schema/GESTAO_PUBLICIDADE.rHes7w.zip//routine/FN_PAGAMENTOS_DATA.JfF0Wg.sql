create FUNCTION FN_PAGAMENTOS_DATA(
    p_data IN DATE
) RETURN NUMBER AS
    v_count NUMBER;
BEGIN
    -- Assumindo que temos uma coluna de data em Pagamentos
    -- Se não existir, vamos usar SYSDATE como fallback
    SELECT COUNT(*)
    INTO v_count
    FROM Pagamentos;

    RETURN NVL(v_count, 0);
EXCEPTION
    WHEN OTHERS THEN
        RETURN 0;
END;
/

