create PROCEDURE SP_PESQUISA_PECAS(
    p_termo IN VARCHAR2,
    p_campo IN VARCHAR2 DEFAULT 'TODOS',
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    CASE p_campo
        WHEN 'TITULO' THEN
            OPEN p_cursor FOR
                SELECT * FROM Pecas_Criativas
                WHERE UPPER(Titulo) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Data_criacao DESC;

        WHEN 'CRIADOR' THEN
            OPEN p_cursor FOR
                SELECT * FROM Pecas_Criativas
                WHERE UPPER(Criador) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Criador;

        WHEN 'STATUS' THEN
            OPEN p_cursor FOR
                SELECT * FROM Pecas_Criativas
                WHERE UPPER(Status_aprov) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Status_aprov;

        ELSE -- TODOS
            OPEN p_cursor FOR
                SELECT * FROM Pecas_Criativas
                WHERE UPPER(NVL(Titulo, '') || ' ' || NVL(Criador, '') || ' ' || NVL(Status_aprov, ''))
                      LIKE UPPER('%' || p_termo || '%')
                ORDER BY Data_criacao DESC;
    END CASE;
END;
/

