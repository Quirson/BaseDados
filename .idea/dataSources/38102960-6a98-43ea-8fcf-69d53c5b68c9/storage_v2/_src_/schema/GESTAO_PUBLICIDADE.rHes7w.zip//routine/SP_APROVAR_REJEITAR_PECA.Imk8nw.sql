create PROCEDURE sp_aprovar_rejeitar_peca (
    p_id_peca IN Pecas_Criativas.Id_unicoPeca%TYPE,
    p_novo_status IN Pecas_Criativas.Status_aprov%TYPE,
    p_justificativa IN VARCHAR2 DEFAULT NULL
)
IS
BEGIN
    UPDATE Pecas_Criativas
    SET Status_aprov = p_novo_status
    WHERE Id_unicoPeca = p_id_peca;

    COMMIT;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20003, 'Peça criativa não encontrada: ' || p_id_peca);
END sp_aprovar_rejeitar_peca;
/

