create FUNCTION FN_RELEVANCIA_PESQUISA(
    p_texto IN VARCHAR2,
    p_termo IN VARCHAR2
) RETURN NUMBER AS
    v_relevancia NUMBER := 0;
    v_texto_upper VARCHAR2(4000);
    v_termo_upper VARCHAR2(255);
BEGIN
    v_texto_upper := UPPER(p_texto);
    v_termo_upper := UPPER(p_termo);

    -- Correspondência exata no início
    IF v_texto_upper LIKE v_termo_upper || '%' THEN
        v_relevancia := v_relevancia + 100;
    END IF;

    -- Correspondência exata em qualquer lugar
    IF v_texto_upper LIKE '%' || v_termo_upper || '%' THEN
        v_relevancia := v_relevancia + 50;
    END IF;

    -- Conta ocorrências
    v_relevancia := v_relevancia +
        (LENGTH(v_texto_upper) - LENGTH(REPLACE(v_texto_upper, v_termo_upper, ''))) /
        GREATEST(LENGTH(v_termo_upper), 1) * 10;

    RETURN v_relevancia;
END;
/

