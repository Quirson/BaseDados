create view V_TOP_PESQUISAS as
SELECT
    Termo_pesquisa,
    COUNT(*) AS Total_pesquisas,
    AVG(Qtd_resultados) AS Media_resultados,
    MAX(Data_pesquisa) AS Ultima_pesquisa
FROM Log_Pesquisas
WHERE Data_pesquisa >= SYSDATE - 30  -- Últimos 30 dias
GROUP BY Termo_pesquisa
ORDER BY COUNT(*) DESC
FETCH FIRST 10 ROWS ONLY
/

