create view V_PESQUISA_GLOBAL as
SELECT
    'ANUNCIANTE' AS TIPO_REGISTRO,
    TO_CHAR(Num_id_fiscal) AS ID_REGISTRO,
    Nome_razao_soc AS TITULO_PRINCIPAL,
    Cat_negocio || ' | ' || Porte AS SUBTITULO,
    'NIF: ' || TO_CHAR(Num_id_fiscal) || ' | ' ||
    'Categoria: ' || Cat_negocio || ' | ' ||
    'Porte: ' || Porte || ' | ' ||
    'Endereço: ' || NVL(Endereco, 'N/A') || ' | ' ||
    'Contatos: ' || NVL(Contactos, 'N/A') AS TEXTO_PESQUISAVEL,
    TO_CHAR(SYSDATE, 'DD/MM/YYYY') AS DATA_REGISTRO
FROM Anunciante_Dados
UNION ALL
SELECT
    'CAMPANHA' AS TIPO_REGISTRO,
    TO_CHAR(Cod_camp) AS ID_REGISTRO,
    NVL(Titulo, 'Sem título') AS TITULO_PRINCIPAL,
    'Orçamento: MT ' || TO_CHAR(NVL(Orc_alocado, 0), '999G999G999D99') AS SUBTITULO,
    'Código: ' || TO_CHAR(Cod_camp) || ' | ' ||
    'Título: ' || NVL(Titulo, 'N/A') || ' | ' ||
    'Público: ' || NVL(Pub_alvo, 'N/A') || ' | ' ||
    'Orçamento: ' || TO_CHAR(NVL(Orc_alocado, 0)) AS TEXTO_PESQUISAVEL,
    TO_CHAR(Data_inicio, 'DD/MM/YYYY') AS DATA_REGISTRO
FROM Campanha_Dados
UNION ALL
SELECT
    'PECA_CRIATIVA' AS TIPO_REGISTRO,
    TO_CHAR(Id_unicopeca) AS ID_REGISTRO,
    NVL(Titulo, 'Sem título') AS TITULO_PRINCIPAL,
    'Criador: ' || NVL(Criador, 'N/A') AS SUBTITULO,
    'ID: ' || TO_CHAR(Id_unicopeca) || ' | ' ||
    'Título: ' || NVL(Titulo, 'N/A') || ' | ' ||
    'Criador: ' || NVL(Criador, 'N/A') || ' | ' ||
    'Status: ' || NVL(Status_aprov, 'N/A') || ' | ' ||
    SUBSTR(NVL(TO_CHAR(Descricao), 'N/A'), 1, 200) AS TEXTO_PESQUISAVEL,
    TO_CHAR(Data_criacao, 'DD/MM/YYYY') AS DATA_REGISTRO
FROM Pecas_Criativas
UNION ALL
SELECT
    'ESPACO' AS TIPO_REGISTRO,
    TO_CHAR(Id_espaco) AS ID_REGISTRO,
    NVL(Local_fis_dig, 'Sem localização') AS TITULO_PRINCIPAL,
    'Tipo: ' || NVL(Tipo, 'N/A') || ' | MT ' || TO_CHAR(NVL(Preco_base, 0), '999G999G999D99') AS SUBTITULO,
    'ID: ' || TO_CHAR(Id_espaco) || ' | ' ||
    'Local: ' || NVL(Local_fis_dig, 'N/A') || ' | ' ||
    'Tipo: ' || NVL(Tipo, 'N/A') || ' | ' ||
    'Dimensões: ' || NVL(Dimensoes, 'N/A') || ' | ' ||
    'Visibilidade: ' || NVL(Visibilidade, 'N/A') || ' | ' ||
    'Disponibilidade: ' || NVL(Disponibilidade, 'N/A') || ' | ' ||
    'Proprietário: ' || NVL(Proprietario, 'N/A') AS TEXTO_PESQUISAVEL,
    TO_CHAR(SYSDATE, 'DD/MM/YYYY') AS DATA_REGISTRO
FROM Espaco_Dados
UNION ALL
SELECT
    'PAGAMENTO' AS TIPO_REGISTRO,
    TO_CHAR(Cod_pagamento) AS ID_REGISTRO,
    'Pagamento #' || TO_CHAR(Cod_pagamento) AS TITULO_PRINCIPAL,
    'Método: ' || NVL(Metod_pagamento, 'N/A') AS SUBTITULO,
    'Código: ' || TO_CHAR(Cod_pagamento) || ' | ' ||
    'Método: ' || NVL(Metod_pagamento, 'N/A') || ' | ' ||
    'Preço: ' || TO_CHAR(NVL(Precos_dinam, 0)) AS TEXTO_PESQUISAVEL,
    TO_CHAR(SYSDATE, 'DD/MM/YYYY') AS DATA_REGISTRO
FROM Pagamentos
UNION ALL
SELECT
    'AGENCIA' AS TIPO_REGISTRO,
    TO_CHAR(Reg_comercial) AS ID_REGISTRO,
    NVL(Nome_age, 'Sem nome') AS TITULO_PRINCIPAL,
    'Equipe: ' || NVL(Equip_principal, 'N/A') AS SUBTITULO,
    'Registro: ' || TO_CHAR(Reg_comercial) || ' | ' ||
    'Nome: ' || NVL(Nome_age, 'N/A') || ' | ' ||
    'Equipe: ' || NVL(Equip_principal, 'N/A') || ' | ' ||
    'Capacidades: ' || NVL(Cap_tecnicas, 'N/A') AS TEXTO_PESQUISAVEL,
    TO_CHAR(SYSDATE, 'DD/MM/YYYY') AS DATA_REGISTRO
FROM Agencia_Dados
/

