create PROCEDURE SP_PESQUISA_AVANCADA(
    p_termo IN VARCHAR2,
    p_tipo IN VARCHAR2 DEFAULT NULL,
    p_data_inicio IN DATE DEFAULT NULL,
    p_data_fim IN DATE DEFAULT NULL,
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            TIPO_REGISTRO,
            ID_REGISTRO,
            TITULO_PRINCIPAL,
            SUBTITULO,
            DATA_REGISTRO,
            FN_RELEVANCIA_PESQUISA(TEXTO_PESQUISAVEL, p_termo) AS SCORE_RELEVANCIA
        FROM V_PESQUISA_GLOBAL
        WHERE
            UPPER(TEXTO_PESQUISAVEL) LIKE UPPER('%' || p_termo || '%')
            AND (p_tipo IS NULL OR TIPO_REGISTRO = p_tipo)
            AND (p_data_inicio IS NULL OR TO_DATE(DATA_REGISTRO, 'DD/MM/YYYY') >= p_data_inicio)
            AND (p_data_fim IS NULL OR TO_DATE(DATA_REGISTRO, 'DD/MM/YYYY') <= p_data_fim)
        ORDER BY
            FN_RELEVANCIA_PESQUISA(TEXTO_PESQUISAVEL, p_termo) DESC,
            TITULO_PRINCIPAL;
END;
/

