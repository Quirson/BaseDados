create PROCEDURE sp_get_detalhes_campanha_completa (
    p_cod_camp IN Campanha_Dados.Cod_camp%TYPE,
    p_cursor OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN p_cursor FOR
    SELECT
        c.*,
        a.Nome_razao_soc AS Anunciante_Nome,
        (SELECT LISTAGG(e.Local_fis_dig, '; ') WITHIN GROUP (ORDER BY e.Local_fis_dig)
         FROM Campanha_Espaco ce
         JOIN Espaco_Dados e ON ce.Id_espaco = e.Id_espaco
         WHERE ce.Cod_camp = c.Cod_camp) AS Espacos,
        (SELECT LISTAGG(pa.Seg_demograf, ' | ') WITHIN GROUP (ORDER BY pa.Id_publicoAlvo)
         FROM Campanha_PublicoAlvo cpa
         JOIN Publico_Alvo pa ON cpa.Id_publicoAlvo = pa.Id_publicoAlvo
         WHERE cpa.Cod_camp = c.Cod_camp) AS Publicos_Alvo,
        fn_calcular_custo_total_campanha(c.Cod_camp) AS Custo_Total
    FROM Campanha_Dados c
    JOIN Anunciante_Dados a ON c.Num_id_fiscal = a.Num_id_fiscal
    WHERE c.Cod_camp = p_cod_camp;
END sp_get_detalhes_campanha_completa;
/

