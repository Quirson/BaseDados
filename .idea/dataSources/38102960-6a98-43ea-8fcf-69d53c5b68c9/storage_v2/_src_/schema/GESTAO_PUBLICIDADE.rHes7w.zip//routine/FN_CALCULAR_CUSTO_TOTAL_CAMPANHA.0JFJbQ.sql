create FUNCTION fn_calcular_custo_total_campanha (
    p_cod_camp IN Campanha_Dados.Cod_camp%TYPE
) RETURN NUMBER
IS
    v_custo_base NUMBER := 0;
    v_desconto NUMBER := 0;
BEGIN
    SELECT NVL(SUM(e.Preco_base), 0)
    INTO v_custo_base
    FROM Campanha_Espaco ce
    JOIN Espaco_Dados e ON ce.Id_espaco = e.Id_espaco
    WHERE ce.Cod_camp = p_cod_camp;

    RETURN v_custo_base;

EXCEPTION
    WHEN OTHERS THEN
        RETURN 0;
END fn_calcular_custo_total_campanha;
/

