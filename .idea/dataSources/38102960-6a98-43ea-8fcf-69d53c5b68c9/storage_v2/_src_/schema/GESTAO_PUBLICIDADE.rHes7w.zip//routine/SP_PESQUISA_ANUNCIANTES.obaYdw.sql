create PROCEDURE SP_PESQUISA_ANUNCIANTES(
    p_termo IN VARCHAR2,
    p_campo IN VARCHAR2 DEFAULT 'TODOS',
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    CASE p_campo
        WHEN 'NOME' THEN
            OPEN p_cursor FOR
                SELECT * FROM Anunciante_Dados
                WHERE UPPER(Nome_razao_soc) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Nome_razao_soc;

        WHEN 'NIF' THEN
            OPEN p_cursor FOR
                SELECT * FROM Anunciante_Dados
                WHERE TO_CHAR(Num_id_fiscal) LIKE '%' || p_termo || '%'
                ORDER BY Num_id_fiscal;

        WHEN 'CATEGORIA' THEN
            OPEN p_cursor FOR
                SELECT * FROM Anunciante_Dados
                WHERE UPPER(Cat_negocio) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Cat_negocio;

        WHEN 'PORTE' THEN
            OPEN p_cursor FOR
                SELECT * FROM Anunciante_Dados
                WHERE UPPER(Porte) LIKE UPPER('%' || p_termo || '%')
                ORDER BY Porte;

        ELSE -- TODOS
            OPEN p_cursor FOR
                SELECT * FROM Anunciante_Dados
                WHERE UPPER(Nome_razao_soc || ' ' || NVL(Cat_negocio, '') || ' ' ||
                           NVL(Porte, '') || ' ' || NVL(Endereco, '') || ' ' || NVL(Contactos, ''))
                      LIKE UPPER('%' || p_termo || '%')
                ORDER BY Nome_razao_soc;
    END CASE;
END;
/

