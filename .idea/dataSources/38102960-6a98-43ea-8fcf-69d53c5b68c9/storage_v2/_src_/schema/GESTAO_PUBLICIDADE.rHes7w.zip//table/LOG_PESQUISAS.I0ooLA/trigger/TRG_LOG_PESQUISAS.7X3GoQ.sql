create trigger TRG_LOG_PESQUISAS
    before insert
    on LOG_PESQUISAS
    for each row
BEGIN
    IF :NEW.Id_log IS NULL THEN
        SELECT Seq_log_pesquisas.NEXTVAL INTO :NEW.Id_log FROM DUAL;
    END IF;

    IF :NEW.Data_pesquisa IS NULL THEN
        :NEW.Data_pesquisa := CURRENT_TIMESTAMP;
    END IF;
END;
/

