create view V_DASHBOARD_ESTATISTICAS as
SELECT
    (SELECT COUNT(*) FROM Anunciante_Dados) as total_anunciantes,
    (SELECT COUNT(*) FROM Campanha_Dados WHERE Data_termino >= SYSDATE) as campanhas_ativas,
    (SELECT NVL(SUM(Orc_alocado), 0) FROM Campanha_Dados WHERE Data_termino >= SYSDATE) as orcamento_total,
    (SELECT COUNT(*) FROM Espaco_Dados WHERE UPPER(DISPONIBILIDADE) = 'DISPONÍVEL') as espacos_disponiveis,
    (SELECT COUNT(*) FROM Pecas_Criativas WHERE UPPER(Status_aprov) = 'APROVADO') as pecas_aprovadas,
    (SELECT COUNT(*) FROM Pecas_Criativas WHERE UPPER(Status_aprov) = 'REJEITADO') as pecas_rejeitadas,
    (SELECT COUNT(*) FROM Pagamentos) as total_pagamentos
FROM DUAL
/

