create FUNCTION FN_CAMPANHAS_INICIADAS_DATA(
    p_data IN DATE
) RETURN NUMBER AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO v_count
    FROM Campanha_Dados
    WHERE TRUNC(Data_inicio) = TRUNC(p_data);

    RETURN NVL(v_count, 0);
EXCEPTION
    WHEN OTHERS THEN
        RETURN 0;
END;
/

