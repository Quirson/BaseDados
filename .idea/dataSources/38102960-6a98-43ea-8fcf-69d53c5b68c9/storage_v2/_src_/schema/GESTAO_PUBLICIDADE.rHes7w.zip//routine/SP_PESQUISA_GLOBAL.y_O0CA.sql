create PROCEDURE SP_PESQUISA_GLOBAL(
    p_termo IN VARCHAR2,
    p_tipo IN VARCHAR2 DEFAULT NULL,
    p_cursor OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT
            TIPO_REGISTRO,
            ID_REGISTRO,
            TITULO_PRINCIPAL,
            SUBTITULO,
            DATA_REGISTRO,
            -- Cálculo de relevância (ranking)
            CASE
                WHEN UPPER(TITULO_PRINCIPAL) LIKE UPPER('%' || p_termo || '%') THEN 3
                WHEN UPPER(SUBTITULO) LIKE UPPER('%' || p_termo || '%') THEN 2
                ELSE 1
            END AS RELEVANCIA
        FROM V_PESQUISA_GLOBAL
        WHERE
            UPPER(TEXTO_PESQUISAVEL) LIKE UPPER('%' || p_termo || '%')
            AND (p_tipo IS NULL OR TIPO_REGISTRO = p_tipo)
        ORDER BY
            CASE
                WHEN UPPER(TITULO_PRINCIPAL) LIKE UPPER('%' || p_termo || '%') THEN 3
                WHEN UPPER(SUBTITULO) LIKE UPPER('%' || p_termo || '%') THEN 2
                ELSE 1
            END DESC,
            TITULO_PRINCIPAL;
END;
/

